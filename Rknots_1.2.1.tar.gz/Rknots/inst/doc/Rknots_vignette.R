### R code from vignette source 'Rknots_vignette.Rnw'

