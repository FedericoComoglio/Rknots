### R code from vignette source 'Rknots_vignette.Rnw'

###################################################
### code chunk number 1: loading
###################################################
library("Rknots")
data(Rolfsen.table)
str( head(Rolfsen.table, 5) )


###################################################
### code chunk number 2: Rknots_vignette.Rnw:57-58
###################################################
head( names(Rolfsen.table) )


###################################################
### code chunk number 3: knotex
###################################################
str( Rolfsen.table['3.1'] )


###################################################
### code chunk number 4: knotms
###################################################
str( head(Rolfsen.table.ms, 5) )
head( names(Rolfsen.table.ms) )


###################################################
### code chunk number 5: link
###################################################
data(link.table)
str( head(link.table, 5) )
head( names(link.table) )


###################################################
### code chunk number 6: seed
###################################################
set.seed(123)


###################################################
### code chunk number 7: example
###################################################
knot <- makeExampleKnot(k = TRUE) #for a knot
link <- makeExampleKnot(k = FALSE) #for a link


###################################################
### code chunk number 8: class (eval = FALSE)
###################################################
## knot.cls <- new('Knot', points3D = knot)
## link.cls <- new('Knot', points3D = link$points3D, ends = link$ends)


###################################################
### code chunk number 9: class1
###################################################
( knot.cls <- newKnot(points3D = knot) )
( link.cls <- newKnot(points3D = link$points3D, ends = link$ends) )


###################################################
### code chunk number 10: getters
###################################################
head( getCoordinates(knot.cls), 5 )
getEnds(knot.cls)
head( link.cls['points3D'], 5)
link.cls['ends']


###################################################
### code chunk number 11: setters
###################################################
knot.bu <- knot.cls #save the original
new.coordinates <- matrix( runif(60), ncol = 3 )
setCoordinates(knot.cls) <- new.coordinates
knot.cls
knot.cls <- knot.bu #back to the original


###################################################
### code chunk number 12: Rknots_vignette.Rnw:134-138
###################################################
link.bu <- link.cls #save the original
setEnds(link.cls) <- c(10, 50, 90)
getEnds(link.cls)
link.cls <- link.bu


###################################################
### code chunk number 13: alexanderbriggs
###################################################
knot.AB <- AlexanderBriggs(points3D = knot, ends = c())
str(knot.AB)
knot.msr <- msr(points3D = knot, ends = c())
str(knot.msr)


###################################################
### code chunk number 14: Rknots_vignette.Rnw:163-164
###################################################
plotDiagram(knot, ends = c(), lwd = 2, main = 'Original Structure')


###################################################
### code chunk number 15: Rknots_vignette.Rnw:169-172
###################################################
par( mfrow=c(1,2) )
plotDiagram(knot.AB$points3D, knot.AB$ends, lwd = 2, main = 'Reduced with Alexander-Briggs')
plotDiagram(knot.msr$points3D, knot.msr$ends, lwd = 2, main = 'Reduced with MSR')


###################################################
### code chunk number 16: Rknots_vignette.Rnw:178-183
###################################################
link.AB <- AlexanderBriggs(points3D = link$points3D, ends = link$ends)
str(link.AB)
link.msr <- msr(points3D = link$points3D, ends = link$ends)
str(link.msr)
plotDiagram(link$points3D, link$ends, lwd = 2, main = 'Original Structure')


###################################################
### code chunk number 17: Rknots_vignette.Rnw:188-191
###################################################
par( mfrow=c(1,2) )
plotDiagram(link.AB$points3D, link.AB$ends, lwd = 2, main = 'Reduced with Alexander-Briggs')
plotDiagram(link.msr$points3D, link.msr$ends, lwd = 2, main = 'Reduced with MSR')


###################################################
### code chunk number 18: classred
###################################################
knot.cls.AB <- reduceStructure(knot.cls, algorithm = 'AB' )
knot.cls.MSR <- reduceStructure(knot.cls, algorithm = 'MSR' )
link.cls.AB <- reduceStructure(link.cls, algorithm = 'AB' )
link.cls.MSR <- reduceStructure(link.cls, algorithm = 'MSR' )
link.cls.AB


###################################################
### code chunk number 19: Rknots_vignette.Rnw:206-210
###################################################
par( mfrow = c(1, 2) )
plot(link.cls.AB, main = 'default') #default
plot(link.cls.AB, lend = 2, lwd = 3, main = 'using par()') #thicker overcrossings. 
#see par() for additional options


###################################################
### code chunk number 20: classinv
###################################################
( delta.k <- computeInvariant( knot.cls.AB, invariant = 'Alexander') )
jones.k <- computeInvariant( knot.cls.AB, invariant = 'Jones', skein.sign = -1)
homfly.k <- computeInvariant( knot.cls.AB, invariant = 'HOMFLY', skein.sign = -1)


###################################################
### code chunk number 21: classinv
###################################################
( delta.l <- computeInvariant( link.cls.AB, invariant = 'Alexander') )
jones.l <- computeInvariant( link.cls.AB, invariant = 'Jones', skein.sign = -1)
homfly.l <- computeInvariant( link.cls.AB, invariant = 'HOMFLY', skein.sign = -1)


###################################################
### code chunk number 22: conversion
###################################################
converted <-HOMFLY2Jones( homfly.k )
identical( converted, jones.k)


###################################################
### code chunk number 23: Rknots_vignette.Rnw:241-242
###################################################
( computeInvariant( link.cls.AB, invariant = 'LK') )


###################################################
### code chunk number 24: Rolfsen (eval = FALSE)
###################################################
## data(Rolfsen.table)
## text <- names(Rolfsen.table)[1 : 6]
## par(mfrow = c(3,2))
## for(i in 1 : 6) { 
##   k <- Rolfsen.table[[i]]
##   k <- newKnot(k)
##   plot(k, lwd = 2, main = text[i], 
##        sub = paste( computeInvariant(k, 'Alexander'), 
##                     computeInvariant(k, 'Jones'),
##                     computeInvariant(k, 'HOMFLY'), sep = '\n'))
## }        


###################################################
### code chunk number 25: prot
###################################################
#from the file system
protein <- loadProtein(system.file("extdata/2k0a.pdb", package="Rknots"))
protein<- loadProtein('2K0A') #from the PDB
str(protein)


###################################################
### code chunk number 26: plot3D (eval = FALSE)
###################################################
## ramp <- colorRamp(c('blue', 'white', 'red'))
## pal <- rgb( ramp(seq(0, 1, length = 109)), max = 255)
## plotKnot3D(protein$A, colors = list( pal ), 
## 	lwd = 8, radius = .4, showNC = TRUE, text = TRUE)


###################################################
### code chunk number 27: Rknots_vignette.Rnw:296-297
###################################################
names(protein)


###################################################
### code chunk number 28: Rknots_vignette.Rnw:300-302
###################################################
protein <- newKnot(protein$A)
protein


###################################################
### code chunk number 29: Rknots_vignette.Rnw:305-306
###################################################
protein.cp <- closeAndProject( protein, w = 2 )


###################################################
### code chunk number 30: plotprotein (eval = FALSE)
###################################################
## par(mfrow = c(1,2))
## plot(protein, main = 'original', lwd = 2)
## plot(protein.cp, main = 'closed & projected', lwd = 2)


###################################################
### code chunk number 31: protinv
###################################################
( delta.p <- computeInvariant( protein.cp, invariant = 'Alexander') )
( jones.p <- computeInvariant( protein.cp, invariant = 'Jones', skein.sign = -1) )
( homfly.p <- computeInvariant( protein.cp, invariant = 'HOMFLY', skein.sign = -1) )


###################################################
### code chunk number 32: getKT
###################################################
getKnotType(polynomial = delta.p, invariant = 'Alexander')
getKnotType(polynomial = homfly.p, invariant = 'HOMFLY')
getKnotType(polynomial = homfly.p, invariant = 'HOMFLY', full.output = TRUE)


###################################################
### code chunk number 33: Rknots_vignette.Rnw:332-337
###################################################
trefoil <- Rolfsen.table[[1]]
trefoil <- newKnot(trefoil)
( homfly.tr <- computeInvariant(trefoil, 'HOMFLY') )
( homfly.tl <- HOMFLY2mirror(homfly.tr) )
identical( homfly.p, homfly.tl )


###################################################
### code chunk number 34: gz0
###################################################
processChain <- function(protein, i) {
	chain <- newKnot(protein[[i]])
	chain <- closeAndProject( chain )
	return( computeInvariant(chain, 'HOMFLY') )
}        

lengthChain <- function(protein, i) return( nrow(protein[[i]]))


###################################################
### code chunk number 35: Rknots_vignette.Rnw:352-359
###################################################
protein <- loadProtein('1AJC', join.gaps = FALSE, cutoff = 7)
str(protein)
chains <- names(protein)        
polynomials <- lapply( 1: length(chains) , 
		function(i) {
			ifelse(lengthChain(protein, i) > 6, processChain(protein, i), 1) } )
cbind(chains, polynomials)        


###################################################
### code chunk number 36: Rknots_vignette.Rnw:362-369
###################################################
protein <- loadProtein('1AJC', join.gaps = TRUE)
str(protein)
chains <- names(protein)        
polynomials <- lapply( 1: length(chains) , 
		function(i) {
			ifelse(lengthChain(protein, i) > 6, processChain(protein, i), 1) } )
cbind(chains, polynomials)        


###################################################
### code chunk number 37: session
###################################################
sessionInfo()


